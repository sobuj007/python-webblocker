import time
from datetime import datetime as dt
path=r"C:\Windows\System32\drivers\etc\hosts"
temp_path = "hosts"
redirect = "127.0.0.1"
website_list = ["www.youtube.com","youtube.com","bikroy.com","www.bikroy.com"]


while True:
    if dt(dt.now().year, dt.now().month, dt.now().day, 1) < dt.now() < dt(dt.now().year, dt.now().month, dt.now().day, 2):
        print("working hours")
        with open(temp_path,'r+') as file:
            content =file.read()
            #print(content)
            for web in website_list:
                if web in content:
                    pass
                else:
                    file.write(redirect+" "+web+"\n")

    else:
        with open(temp_path,'r+')as file:
            content= file.readlines()
            file.seek(0)
            for line in content:
                if not any(web in line for web in website_list):
                    file.write(line)
            file.truncate()
        print("fun time")
    time.sleep(5)